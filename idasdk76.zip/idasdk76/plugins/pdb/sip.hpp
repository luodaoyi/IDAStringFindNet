
#ifndef PDB_SIP_H
#define PDB_SIP_H

bool apply_debug_info(pdbargs_t &pdbargs);

#include "pdbaccess.hpp"

#endif // PDB_SIP_H
